import javax.swing.*;
import javax.swing.JFrame;

public class Test {
    public static void main(String[] args) {

        MyFrame frame=new MyFrame();

    }
}