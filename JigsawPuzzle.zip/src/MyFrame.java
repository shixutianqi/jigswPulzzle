import org.w3c.dom.ls.LSOutput;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Random;

/**创建一个继承于JFrame的类，该类不仅有JFrame的全部方法，还可以自己定义新的方法*/
public class MyFrame extends JFrame implements KeyListener {
    //-------------成员变量----------------------------
    //设置图片编号数组
    int[][] nums= new int[][]{
            {1,2,3,4},
            {5,6,7,8},
            {9,10,11,12},
            {13,14,15,16}
    };
    //用来对比是否成功的数组
    int[][] wins= new int[][]{
            {1,2,3,4},
            {5,6,7,8},
            {9,10,11,12},
            {13,14,15,16}
    };
    int row;       //黑色方块的行坐标
    int column;    //黑色方块的列坐标
    int count;     //统计步数的计数器

    //-------------成员变量----------------------------


    /**创建构造方法，在实例化该类的对象的时候初始化界面*/
    public MyFrame(){
        initFrame();            //初始化界面
        randomNums();           //打乱界面
        paintView();            //绘制界面

        super.addKeyListener(this);        //注册事件监听器，形参是接口KeyListener的实现类MyFrame（this引用）或者匿名内部类

        setVisible(true);  //设置界面可视化,最好放在最后面执行,因为该类继承了JFrame且没有重写setVisible()方法，所以省略“super.”不写

    }

    /**该方法用于初始化界面*/
    private void initFrame(){
        /**以下代码用于创建拼图游戏的界面*/
        //JFrame frame=new JFrame();        //super已经调用了JFrame中所有的变量和方法，并且可以省略不写，所有可以不要实例化JFrame对象
        super.setTitle("拼图游戏-阉割单机版");                 //设置标题
        setSize(510,630);                    //界面大小
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);   //设置关闭界面结束运行代码
        setAlwaysOnTop(true);                             //设置界面在最顶层
        setLocationRelativeTo(null);                      //设置界面居中
        setLayout(null);                                  //取消窗口默认布局
    }
    /**该方法用于给界面添加组件*/
    private void paintView(){

        //由于每次添加标签都是向上顶，会被上一个标签挡住，所以每次绘制界面都要移除所有组件
        getContentPane().removeAll();

        //胜利
        if(victory()){
            System.out.println("你一共花了"+count+"步，赢得了游戏！");
            JLabel jl0=new JLabel(new ImageIcon(("D:\\images\\win.png")));
            jl0.setBounds(100,200,324,285);
            super.getContentPane().add(jl0);
        }

        //将所有图片标签添加到容器中
        for(int j=0;j<4;j++)
        {
            for(int i=0;i<4;i++)
            {
                int n=nums[j][i];
                //根据编号找到图片地址（图片以1-16命名）
                JLabel jLabel=new JLabel(new ImageIcon("D:\\images\\pingTu_"+n+".png"));
                jLabel.setBounds(10+120*i,110+120*j,120,120);
                super.getContentPane().add(jLabel);
            }
        }
        //添加计数器组件
        JLabel jcount=new JLabel("操作步数："+count);
        jcount.setSize(100,80);
        jcount.setBounds(50,0,100,100);
        super.getContentPane().add(jcount);
        //添加重写开始游戏按钮
        JButton jb=new JButton("重新开始游戏");
        jb.addActionListener(e -> {           //Lambda表达式
            count=0;
            randomNums();
            paintView();
        });
        jb.setBounds(300,20,150,80);
        jb.setFocusable(false);                        //取消按钮的焦点
        super.getContentPane().add(jb);


        getContentPane().repaint();    //刷新界面
    }

    /**该方法用于打乱图片序号*/
    private void randomNums() {

        Random random=new Random();

        for(int j=0;j<4;j++)
        {
            for(int i=0;i<4;i++)
            {
                int ri=random.nextInt(3)+1;
                int rj=random.nextInt(3)+1;
                //交换两个数组元素位置
                int temp=nums[i][j];
                nums[i][j]=nums[ri][rj];
                nums[ri][rj]=temp;
            }
        }

        //遍历数组找到黑块的坐标
        for (int i = 0; i < nums.length; i++) {
            for (int j = 0; j < nums[i].length; j++) {
                if(nums[i][j]==16)
                {
                    row=i;                       //找到了16号黑块就将它的行列序号赋值给成员变量row，column
                    column=j;
                }
            }
        }

    }

    /**该方法用于比较是否成功完成游戏*/
    private boolean victory(){
        for (int i = 0; i < nums.length; i++) {
            for (int j = 0; j < nums[i].length; j++) {
                if(nums[i][j]!=wins[i][j]){
                    return false;
                }
            }
        }
        return true;
    }

    /**该方法完成移动业务*/
    private void move(int keyCode){
        if(keyCode==37){
            //column++ 右边的图片和黑块交换位置
            if (column == 3)
            {
                System.out.println("不能再左了");
                return;
            }
            int temp=nums[row][column];
            nums[row][column]=nums[row][column+1];
            nums[row][column+1]=temp;
            column++;
            count++;
        }
        else if(keyCode==38){
            //row++
            if (row == 3)
            {
                System.out.println("不能再上了");
                return;
            }
            int temp=nums[row][column];
            nums[row][column]=nums[row+1][column];
            nums[row+1][column]=temp;
            row++;
            count++;
        }
        else if(keyCode==39){
            //column--
            if (column == 0)
            {
                System.out.println("不能再右了");
                return;
            }
            int temp=nums[row][column];
            nums[row][column]=nums[row][column-1];
            nums[row][column-1]=temp;
            column--;
            count++;
        }else if(keyCode==40){
            //row--
            if (row == 0)
            {
                System.out.println("不能再下了");
                return;
            }
            int temp=nums[row][column];
            nums[row][column]=nums[row-1][column];
            nums[row-1][column]=temp;
            row--;
            count++;
        }else if(keyCode==192){                              //190=='`~',设置作弊建
            //排出顺序序号
            int c=1;
            for (int i = 0; i < nums.length; i++) {
                for (int j = 0; j < nums[i].length; j++) {
                    nums[i][j]=c++;
                }
            }
            paintView();
            row=3;                          //作弊排序以后要校正黑块的坐标
            column=3;

        }

 }
    /**该重写方法用作处理移动业务*/
    @Override
    public void keyPressed(KeyEvent e) {

        int keyCode=e.getKeyCode();                            //获得按下的按键的值 左：37 上：38 右：39 下：40
        move(keyCode);
        paintView();
        }


    //----------------KeyListener接口的这两个方法用不上，也不需要重写---------------
    //-----------------------------------------------------------------------
    @Override
    public void keyReleased(KeyEvent e) {

    }
    @Override
    public void keyTyped(KeyEvent e) {

    }
    //-----------------------------------------------------------------------
}
